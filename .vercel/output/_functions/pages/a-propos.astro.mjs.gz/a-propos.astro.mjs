import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yuAGbZrg.mjs';
import { $ as $$Layout } from '../chunks/Layout_-GPg4m4z.mjs';
import { $ as $$Button } from '../chunks/Button_Bo0Bj-8a.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  const theme = "les-12-fragments";
  const firstSectionTheme = "echo-safe";
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "theme": theme, "firstSectionTheme": firstSectionTheme, "title": "\xC0 propos - Bryan Thierry" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="mx-4 md:mx-8 lg:mx-16 py-10 pt-25 bg-[var(--b1)]" data-theme="echo-safe"> <div class="grid grid-cols-1 md:grid-cols-3 gap-6"> <div class="md:col-span-1 flex justify-center items-center"> <img src="/avatar/a-propos_1.webp" alt="Photo de Bryan Thierry" class="w-full max-w-[300px] h-auto object-cover" width="300" height="300" loading="eager"> </div> <div class="md:col-span-2 flex flex-col justify-center"> <!-- Contenu de droite à ajouter ici --> <h1 class="text-4xl font-primary mb-6">À propos de moi</h1> <p class="mb-4">
Salut ! Je m'appelle Bryan et je suis un Développeur Front-End
          passionné spécialisé dans la création d'expériences numériques qui
          font la différence.
</p> <p class="mb-4">
Ma mission est de construire des sites web qui sont à la fois
          performants, accessibles et parfaitement adaptés à tous les supports.
</p> <p class="mb-4">
Mon cœur de métier ? Rendre votre Identité Visuelle éclatante et
          fluide grâce à un Design Responsive rigoureux et une Optimisation SEO
          dès la première ligne de code.
</p> <p class="mb-4">
Je crois fermement qu'un code soigné n'est pas seulement technique,
          c'est aussi un engagement : c'est pourquoi je mets la Sobriété
          Numérique au centre de chaque projet pour un web plus rapide et plus
          durable.
</p> </div> </div> </section>  <section class="mx-4 md:mx-8 lg:mx-16 py-10 bg-[var(--b1)]" data-theme="omnisphere"> <div class="grid grid-cols-1 md:grid-cols-3 gap-8"> <!-- Frise chronologique à gauche (2/3) --> <div class="md:col-span-2 order-2 md:order-1"> <h2 class="font-primary mb-8 text-center">Mon Parcours</h2> <div class="relative"> <!-- Ligne verticale de la frise --> <div class="absolute left-6 top-0 bottom-0 w-1 shadow-lg timeline-line"></div> <!-- Élément de timeline --> <div class="relative flex items-start mb-10"> <div class="flex-shrink-0 w-14 h-14 shadow-xl flex items-center justify-center z-10 transform-rotate-45 transition-colors duration-300 timeline-badge"> <span class="font-primary text-xs transform-rotate-neg-45 timeline-badge-text">
BAC
</span> </div> <div class="ml-8 p-6 rounded-none shadow-lg transform-rotate-neg-1 hover-rotate-0 transition-all duration-300 timeline-card-primary"> <h3 class="font-primary text-xl mb-2 timeline-card-title-primary">
APRÈS LE BAC
</h3> <p class="font-medium">
J'ai choisi le BUT Métiers du Multimédia et de l'Internet (MMI)
                pour maîtriser l'ensemble de la conception web.
</p> </div> </div> <!-- Formation MMI --> <div class="relative flex items-start mb-10"> <div class="flex-shrink-0 w-14 h-14 shadow-xl flex items-center justify-center z-10 transform-rotate-12 transition-colors duration-300 timeline-badge-secondary"> <span class="font-primary text-xs transform-rotate-neg-12 timeline-badge-text">
MMI
</span> </div> <div class="ml-8 p-6 rounded-none shadow-lg transform-rotate-1 hover-rotate-0 transition-all duration-300 timeline-card-secondary"> <h3 class="font-primary text-xl mb-2 timeline-card-title-secondary">
FORMATION BUT MMI
</h3> <p class="font-medium">
Cours complet couvrant la gestion de projet, la communication,
                le design UI/UX et la maîtrise du code (HTML, CSS, JavaScript).
</p> </div> </div> <!-- Projets pratiques --> <div class="relative flex items-start mb-10"> <div class="shrink-0 w-14 h-14 shadow-xl flex items-center justify-center z-10 transform-rotate-neg-12 transition-colors duration-300 timeline-badge-accent"> <span class="font-primary text-xs transform-rotate-12 timeline-badge-text">
PRO
</span> </div> <div class="ml-8 p-6 rounded-none shadow-lg transform-rotate-neg-1 hover-rotate-0 transition-all duration-300 timeline-card-accent"> <h3 class="font-primary text-xl mb-3 timeline-card-title-accent">
MISE EN PRATIQUE
</h3> <p class="font-medium mb-4">
J'ai mis ces bases en pratique à travers une série de projets
                concrets et variés, prouvant ma capacité à traduire une vision
                créative en un produit technique solide et performant.
</p> <!-- Liste des projets - Descriptions détaillées --> <div class="grid grid-cols-2 gap-2"> <div class="p-3 shadow-sm transform-rotate-1 hover-rotate-0 transition-all duration-300 h-32 flex flex-col justify-center text-center timeline-project-card"> <h4 class="font-primary text-sm mb-1 timeline-project-title">
ECHO SAFE
</h4> <p class="text-xs timeline-project-text">
Application solidaire contre le harcèlement avec messagerie
                    sécurisée
</p> </div> <div class="p-3 shadow-sm transform-rotate-neg-1 hover-rotate-0 transition-all duration-300 h-32 flex flex-col justify-center text-center timeline-project-card"> <h4 class="font-primary text-sm mb-1 timeline-project-title">
ÇA VA TRAILER
</h4> <p class="text-xs timeline-project-text">
Vitrine immersive pour un festival de cinéma avec identité
                    visuelle forte
</p> </div> <div class="p-3 shadow-sm transform-rotate-1 hover-rotate-0 transition-all duration-300 h-32 flex flex-col justify-center text-center timeline-project-card"> <h4 class="font-primary text-sm mb-1 timeline-project-title">
RBA
</h4> <p class="text-xs timeline-project-text">
Refonte complète de l'identité visuelle pour l'association
                    biodiversité
</p> </div> <div class="p-3 shadow-sm transform-rotate-neg-1 hover-rotate-0 transition-all duration-300 h-32 flex flex-col justify-center text-center timeline-project-card"> <h4 class="font-primary text-sm mb-1 timeline-project-title">
12 FRAGMENTS
</h4> <p class="text-xs timeline-project-text">
Site créatif et narratif autour de 12 avatars en pixel art
</p> </div> <div class="p-3 shadow-sm transform-rotate-1 hover-rotate-0 transition-all duration-300 h-32 flex flex-col justify-center text-center col-span-2 timeline-project-card"> <h4 class="font-primary text-sm mb-1 timeline-project-title">
OMNISPHERE
</h4> <p class="text-xs timeline-project-text">
Site immersif questionnant l'avenir des relations humaines
                    avec design futuriste
</p> </div> </div> </div> </div> <!-- Objectif --> <div class="relative flex items-start"> <div class="shrink-0 w-14 h-14 shadow-xl flex items-center justify-center z-10 transform-rotate-45 transition-colors duration-300 timeline-badge"> <span class="font-primary text-xs transform-rotate-neg-45 timeline-badge-text">
GO!
</span> </div> <div class="ml-8 p-6 rounded-none shadow-lg transform-rotate-1 hover-rotate-0 transition-all duration-300 timeline-card-primary"> <h3 class="font-primary text-xl mb-3 timeline-card-title-primary">
MON OBJECTIF
</h3> <p class="font-medium mb-6">
Livrer des solutions numériques qui sont à la fois performantes
                et pleines de sens.
</p> <div class="p-4 text-center"> ${renderComponent($$result2, "Button", $$Button, { "href": "/projets", "className": "bg-white text-purple-900 hover:bg-purple-100 font-primary text-lg", "theme": "omnisphere" }, { "default": ($$result3) => renderTemplate`
VOIR MES PROJETS !
` })} </div> </div> </div> </div> </div> <!-- Image sticky à droite (1/3) --> <div class="md:col-span-1 order-1 md:order-2"> <div class="sticky top-32"> <img src="/avatar/a-propos_2.webp" alt="Bryan Thierry - Mon parcours" class="w-full max-w-[300px] h-auto object-cover mx-auto"> </div> </div> </div> </section>  <section class="mx-4 md:mx-8 lg:mx-16 py-10 bg-[var(--b1)]" data-theme="orange"> <div class="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start"> <!-- Image du personnage à gauche (1/3) --> <div class="lg:col-span-1 flex justify-center"> <div class="sticky top-32 h-fit"> <img src="/avatar/a-propos_3.webp" alt="Bryan Thierry - Character" class="w-full h-auto max-w-sm"> </div> </div> <!-- Contenu des compétences à droite (2/3) --> <div class="lg:col-span-2"> <!-- Titre principal --> <h2 class="font-primary text-center mb-5">MES COMPÉTENCES</h2> <!-- Section Compétences --> <div class="mb-8"> <!-- Première ligne : Design et Vidéo --> <div class="flex justify-center mb-6"> <div class="grid grid-cols-5 gap-8"> <!-- Figma --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/figma.svg" alt="Figma" class="h-10"> </div> <p class="font-primary text-sm">FIGMA</p> </div> <!-- Illustrator --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/adobe_illustrator.svg" alt="Illustrator" class="w-10 h-10"> </div> <p class="font-primary text-sm">ILLUSTRATOR</p> </div> <!-- Photoshop --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/adobe_photoshop.svg" alt="Photoshop" class="w-10 h-10"> </div> <p class="font-primary text-sm">PHOTOSHOP</p> </div> <!-- After Effect --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/adobe_after_effects.svg" alt="After Effects" class="w-10 h-10"> </div> <p class="font-primary text-sm">AFTER EFFECT</p> </div> <!-- Premiere Pro --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/adobe_premiere.svg" alt="Premiere Pro" class="w-10 h-10"> </div> <p class="font-primary text-sm">PREMIERE PRO</p> </div> </div> </div> </div> <!-- Deuxième ligne : Développement --> <div class="mb-10"> <div class="flex justify-center"> <div class="grid grid-cols-5 gap-8"> <!-- VS Code --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/vs_code.svg" alt="VS Code" class="w-10 h-10"> </div> <p class="font-primary text-sm">VS CODE</p> </div> <!-- JavaScript --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/js.svg" alt="JavaScript" class="w-10 h-10"> </div> <p class="font-primary text-sm">JAVASCRIPT</p> </div> <!-- CSS --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/css_3.svg" alt="CSS" class="w-10 h-10"> </div> <p class="font-primary text-sm">CSS</p> </div> <!-- HTML --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/html_5.svg" alt="HTML" class="w-10 h-10"> </div> <p class="font-primary text-sm">HTML</p> </div> <!-- WordPress --> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/wordpress-tile1.svg" alt="WordPress" class="w-10 h-10"> </div> <p class="font-primary text-sm">WORDPRESS</p> </div> </div> </div> </div> <!-- Troisième ligne : Productivité (Notion seul, centré) --> <div class="flex justify-center"> <div class="text-center group cursor-pointer"> <div class="w-16 h-16 mx-auto mb-2 bg-transparent rounded-xl flex items-center justify-center transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 p-2"> <img src="/competences/notion.svg" alt="Notion" class="w-10 h-10"> </div> <p class="font-primary text-sm">NOTION</p> </div> </div> </div> </div> </section>  <section class="mx-4 md:mx-8 lg:mx-16 py-10 bg-[var(--b1)]" data-theme="les-12-fragments"> <div class="grid grid-cols-1 lg:grid-cols-3 gap-12"> <!-- Contenu texte à gauche (2/3) --> <div class="lg:col-span-2 order-2 lg:order-1"> <!-- Titre principal --> <h2 class="font-primary text-4xl mb-8 transform-rotate-neg-1 text-color-p">
MON PROCHAIN CHAPITRE
</h2> <!-- Sous-sections --> <div class="space-y-8"> <!-- Partenaire Web Fiable --> <div class="p-6 shadow-lg transform-rotate-1 hover-rotate-0 transition-all duration-300 timeline-card-primary"> <h3 class="font-primary text-2xl mb-4 timeline-card-title-primary">
PARTENAIRE WEB FIABLE
</h3> <p class="font-medium leading-relaxed">
Ma priorité ? Devenir un partenaire fiable et polyvalent. Je
              souhaite créer des solutions web qui allient performance technique
              et identité visuelle marquante.
</p> </div> <!-- Créateur de Contenu --> <div class="p-6 shadow-lg transform-rotate-neg-1 hover-rotate-0 transition-all duration-300 timeline-card-secondary"> <h3 class="font-primary text-2xl mb-4 timeline-card-title-secondary">
CRÉATEUR DE CONTENU ET STORYTELLING
</h3> <p class="font-medium leading-relaxed">
Mon ambition principale est d'étendre mon domaine de création : je
              souhaite devenir un créateur de contenu polyvalent avec ma future
              chaîne YouTube et mon blog.
</p> </div> <!-- Projets et Innovation --> <div class="p-6 shadow-lg transform-rotate-1 hover-rotate-0 transition-all duration-300 timeline-card-accent"> <h3 class="font-primary text-2xl mb-4 timeline-card-title-accent">
PROJETS ET INNOVATION FUTURE
</h3> <p class="font-medium leading-relaxed">
Ma curiosité m'incite à repousser les limites techniques. Je
              prévois de maîtriser la 3D avec Blender et Unreal Engine pour
              créer des expériences immersives.
</p> </div> </div> <!-- Call to Action --> <div class="text-center mt-12"> ${renderComponent($$result2, "Button", $$Button, { "href": "#contact", "className": "font-primary text-xl px-8 py-4", "theme": "les-12-fragments" }, { "default": ($$result3) => renderTemplate`
COLLABORONS ENSEMBLE !
` })} </div> </div> <!-- Image sticky à droite (1/3) --> <div class="lg:col-span-1 order-1 lg:order-2"> <div class="sticky top-32"> <img src="/avatar/a-propos_4.webp" alt="Bryan Thierry - Futur" class="w-full max-w-[300px] h-auto object-cover mx-auto transform"> </div> </div> </div> </section> ` })}`;
}, "C:/Users/bryan/Documents/GitHub/site_portfolio2.0/src/pages/a-propos/index.astro", void 0);

const $$file = "C:/Users/bryan/Documents/GitHub/site_portfolio2.0/src/pages/a-propos/index.astro";
const $$url = "/a-propos";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
