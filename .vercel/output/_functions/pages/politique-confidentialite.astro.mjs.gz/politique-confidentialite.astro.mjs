import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yuAGbZrg.mjs';
import { $ as $$Layout } from '../chunks/Layout_-GPg4m4z.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Politique de Confidentialit\xE9 - Bryan Thierry", "theme": "basique" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="min-h-screen py-32 px-6 md:px-12 bg-(--b1)"> <div class="max-w-4xl mx-auto"> <!-- En-tête --> <h1 class="text-5xl md:text-7xl font-primary text-(--p) mb-8 uppercase">
Politique de Confidentialité
</h1> <!-- Politique inspirée du modèle fourni --> <div class="space-y-8 font-secondary text-(--bc)"> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">1. Responsable du traitement</h2> <p class="leading-relaxed mb-2">Bryan Thierry</p> <p class="leading-relaxed mb-2">Email : <a href="mailto:bryan.thierry.pro@gmail.com" class="text-(--p) hover:underline">bryan.thierry.pro@gmail.com</a></p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">2. Données personnelles collectées</h2> <p class="leading-relaxed mb-2">Ce site ne collecte aucune donnée personnelle, sauf si vous utilisez un formulaire de contact (si présent).</p> <p class="leading-relaxed">Les données collectées via le formulaire sont : nom, prénom, adresse email, contenu du message (et téléphone si renseigné).</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">3. Finalité de la collecte</h2> <p class="leading-relaxed">Les informations transmises via le formulaire sont utilisées uniquement pour répondre à votre demande de contact. La base légale est votre consentement (art. 6.1.a RGPD).</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">4. Durée de conservation</h2> <p class="leading-relaxed">Les données sont conservées le temps nécessaire au traitement de votre demande, et au maximum 3 ans après le dernier échange, sauf obligation légale contraire.</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">5. Partage et destinataires</h2> <p class="leading-relaxed">Les données sont destinées à l'usage exclusif de Bryan Thierry et ne sont jamais vendues ou cédées à des tiers.</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">6. Hébergement des données</h2> <p class="leading-relaxed">Les données transmises via le formulaire peuvent être stockées dans une base PocketBase hébergée en Suisse chez Infomaniak.</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">7. Vos droits (RGPD)</h2> <p class="leading-relaxed mb-2">Conformément au RGPD, vous disposez des droits suivants :</p> <ul class="list-disc list-inside space-y-2 ml-4"> <li>Droit d'accès</li> <li>Droit de rectification</li> <li>Droit à l'effacement</li> <li>Droit d'opposition</li> <li>Droit à la limitation</li> <li>Droit à la portabilité</li> </ul> <p class="leading-relaxed mt-2">Pour exercer vos droits, contactez : <a href="mailto:bryan.thierry.pro@gmail.com" class="text-(--p) hover:underline">bryan.thierry.pro@gmail.com</a></p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">8. Cookies</h2> <p class="leading-relaxed">Le site n'utilise aucun cookie de suivi ou de marketing. Seuls des cookies techniques essentiels au bon fonctionnement du site peuvent être utilisés (préférences de thème, affichage).</p> </div> <div class="pt-8 border-t-2 border-(--bc) mt-12"> <p class="text-sm opacity-70">Dernière mise à jour : Novembre 2025</p> </div> </div> </div> </section> ` })}`;
}, "C:/Users/bryan/Documents/GitHub/site_portfolio2.0/src/pages/politique-confidentialite/index.astro", void 0);

const $$file = "C:/Users/bryan/Documents/GitHub/site_portfolio2.0/src/pages/politique-confidentialite/index.astro";
const $$url = "/politique-confidentialite";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
