import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_yuAGbZrg.mjs';
import { $ as $$Layout } from '../chunks/Layout_-GPg4m4z.mjs';
export { renderers } from '../renderers.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Mentions L\xE9gales - Bryan Thierry", "theme": "basique" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="min-h-screen py-32 px-6 md:px-12 bg-(--b1)"> <div class="max-w-4xl mx-auto"> <!-- En-tête --> <h1 class="text-5xl md:text-7xl font-primary text-(--p) mb-8 uppercase">
Mentions Légales
</h1> <!-- Contenu inspiré du modèle fourni --> <div class="space-y-8 font-secondary text-(--bc)"> <div> <p class="leading-relaxed mb-4">
Conformément à la loi n° 2004-575 du 21 juin 2004 pour la confiance
            dans l'économie numérique, il est précisé aux utilisateurs
            l'identité des intervenants du site.
</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
1. Édition du site
</h2> <p class="leading-relaxed mb-2"> <strong>Nom :</strong> Bryan Thierry
</p> <p class="leading-relaxed mb-2"> <strong>Statut :</strong> Auto-entrepreneur
</p> <p class="leading-relaxed mb-2"> <strong>Email :</strong> <a href="mailto:bryan.thierry.pro@gmail.com" class="text-(--p) hover:underline">bryan.thierry.pro@gmail.com</a> </p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
2. Directeur de la publication
</h2> <p class="leading-relaxed">
Le directeur de la publication est Bryan Thierry.
</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
3. Hébergement
</h2> <p class="leading-relaxed mb-2">
Ce site est hébergé par <strong>Infomaniak Network SA</strong>.
</p> <p class="leading-relaxed mb-2">
Rue Eugène-Marziano 25, 1227 Les Acacias (GE), Suisse
</p> <p class="leading-relaxed mb-2">
Contact : <a href="tel:+41228203540" class="text-(--p) hover:underline">+41 22 820 35 40</a> </p> <p class="leading-relaxed"> <a href="https://www.infomaniak.com" target="_blank" rel="noopener noreferrer" class="text-(--p) hover:underline">www.infomaniak.com</a> </p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
4. Propriété intellectuelle
</h2> <p class="leading-relaxed mb-2">
Le contenu de ce site est la propriété exclusive de Bryan Thierry,
            sauf mention contraire.
</p> <p class="leading-relaxed">
Toute reproduction ou publication, même partielle, est strictement
            interdite sans un accord écrit.
</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
5. Données personnelles
</h2> <p class="leading-relaxed mb-2">
Ce site ne collecte aucune donnée personnelle, sauf si vous utilisez
            un formulaire de contact (si présent).
</p> <p class="leading-relaxed">
Les données éventuellement transmises via un formulaire sont
            utilisées uniquement pour répondre à votre demande et ne sont jamais
            cédées à des tiers.
</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
6. Cookies
</h2> <p class="leading-relaxed mb-2">
Le site n'utilise aucun cookie de suivi ou de marketing. Seuls des
            cookies techniques essentiels au bon fonctionnement du site
            (préférences de thème, affichage) peuvent être utilisés.
</p> </div> <div> <h2 class="text-2xl font-primary text-(--p) mb-4 uppercase">
7. Loi applicable
</h2> <p class="leading-relaxed">
Les présentes mentions légales sont régies par le droit français.
            Tout litige relatif à l'utilisation de ce site sera soumis à la
            compétence exclusive des tribunaux français.
</p> </div> <div class="pt-8 border-t-2 border-(--bc) mt-12"> <p class="text-sm opacity-70">Dernière mise à jour : Novembre 2025</p> </div> </div> </div> </section> ` })}`;
}, "C:/Users/bryan/Documents/GitHub/site_portfolio2.0/src/pages/mentions-legales/index.astro", void 0);

const $$file = "C:/Users/bryan/Documents/GitHub/site_portfolio2.0/src/pages/mentions-legales/index.astro";
const $$url = "/mentions-legales";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
